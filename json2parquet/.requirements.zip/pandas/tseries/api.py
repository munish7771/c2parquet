"""
Timeseries API
"""

# flake8: noqa

from pandas.tseries.frequencies import infer_freq
import pandas.tseries.offsets as offsets
